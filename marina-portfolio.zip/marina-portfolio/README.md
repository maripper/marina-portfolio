# Marina Ripper's Portfolio

- Welcome to my Portfolio! My Name is Marina Ripper and I am a Software Developer and Artist!

- To Access My Portfolio got to: 

